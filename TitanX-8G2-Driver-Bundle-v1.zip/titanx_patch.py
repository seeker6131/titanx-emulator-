from pathlib import Path
from datetime import datetime

ROOT = Path('winlator')

def patch(rel, old, new):
    path=ROOT/rel
    text=path.read_text(encoding='utf-8')
    n=text.count(old)
    if n!=1:
        raise ValueError(f'UPSTREAM MISMATCH {rel}: found {n} anchors: {old[:100]!r}')
    path.write_text(text.replace(old,new,1),encoding='utf-8')
    print('PATCHED',rel)

# Installable app identity, avoid conflict with user's Winlator or previous TitanX trial.
patch('app/build.gradle', "applicationId 'com.winlator'", "applicationId 'com.titanx.engine8gb'")
patch('app/build.gradle', 'versionCode 33', 'versionCode 410')
patch('app/build.gradle', 'versionName "11.2"', 'versionName "4.1.0-beta"')
patch('app/src/main/res/values/strings.xml', '<string name="app_name">Winlator</string>', '<string name="app_name">TitanX 8GB - Winlator Based</string>')
patch('app/src/main/AndroidManifest.xml', 'android:authorities="com.winlator.FileProvider"', 'android:authorities="${applicationId}.FileProvider"')
patch('app/src/main/java/com/winlator/core/FileUtils.java', 'FileProvider.getUriForFile(activity, "com.winlator.FileProvider", file)', 'FileProvider.getUriForFile(activity, activity.getPackageName()+".FileProvider", file)')
patch('app/src/main/cpp/winlator/include/winlator.h', '#define APP_CACHE_DIR "/data/data/com.winlator/cache"', '#define APP_CACHE_DIR "/data/data/com.titanx.engine8gb/cache"')

# Only automatically apply profile to real S23 Ultra physical ~8GB models.
newfile=ROOT/'app/src/main/java/com/winlator/TitanXDevice.java'
if newfile.exists(): raise ValueError('Device helper already exists in upstream')
newfile.write_text('''package com.winlator;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Build;
import java.util.Locale;

/** TitanX default profile auto-detection, not a benchmark. */
public final class TitanXDevice {
    private TitanXDevice() {}

    public static boolean isOptimizedDevice(Context ctx) {
        String model = Build.MODEL == null ? "" : Build.MODEL.toUpperCase(Locale.ROOT);
        if (!model.startsWith("SM-S918")) return false;
        ActivityManager manager = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
        if (manager == null) return false;
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        manager.getMemoryInfo(info);
        long gb = 1024L * 1024L * 1024L;
        return info.totalMem >= 6L * gb && info.totalMem < 10L * gb;
    }
}
''',encoding='utf-8')

# Built-in version dropdowns, with real .tzst assets supplied by the bundle.
p='app/src/main/java/com/winlator/core/GeneralComponents.java'
patch(p, 'items = new String[]{DefaultVersion.TURNIP};',
      'items = new String[]{DefaultVersion.TURNIP, "27.0.0-r3-8G2"};')
patch(p, 'items = new String[]{DefaultVersion.MINOR_DXVK, DefaultVersion.MAJOR_DXVK};',
      'items = new String[]{DefaultVersion.MINOR_DXVK, DefaultVersion.MAJOR_DXVK, "2.4.1-user", "2.6.9-gplall-test"};')
# Upstream strips suffix from versions; make custom version selections resolve to actual tarball.
patch('app/src/main/java/com/winlator/contentdialog/TurnipConfigDialog.java',
      'newConfig.put("version", StringUtils.parseNumber(sVersion.getSelectedItem()));',
      'newConfig.put("version", sVersion.getSelectedItem().toString());')

# Retain baseline original driver as default, user chooses modded Turnip and experimental DXVK.
# Add two conservative Box64 presets to the existing dropdown.
p='app/src/main/java/com/winlator/box64/Box64PresetManager.java'
patch(p, 'public abstract class Box64PresetManager {', '''public abstract class Box64PresetManager {
    public static final String TITANX_BALANCED = "TITANX_BALANCED_8GB";
    public static final String TITANX_LOW_RAM = "TITANX_LOW_RAM_8GB";''')
patch(p, '        if (id.equals(Box64Preset.STABILITY)) {', '''        if (id.equals(TITANX_BALANCED)) {
            envVars.put("BOX64_DYNAREC_SAFEFLAGS", "2");
            envVars.put("BOX64_DYNAREC_FASTNAN", "1");
            envVars.put("BOX64_DYNAREC_FASTROUND", "1");
            envVars.put("BOX64_DYNAREC_X87DOUBLE", "0");
            envVars.put("BOX64_DYNAREC_BIGBLOCK", "2");
            envVars.put("BOX64_DYNAREC_STRONGMEM", "1");
            envVars.put("BOX64_DYNAREC_FORWARD", "128");
            envVars.put("BOX64_DYNAREC_CALLRET", "0");
            envVars.put("BOX64_DYNAREC_WAIT", "1");
            envVars.put("BOX64_DYNAREC_NATIVEFLAGS", "0");
            envVars.put("BOX64_DYNAREC_WEAKBARRIER", "1");
        }
        else if (id.equals(TITANX_LOW_RAM)) {
            envVars.put("BOX64_DYNAREC_SAFEFLAGS", "2");
            envVars.put("BOX64_DYNAREC_FASTNAN", "0");
            envVars.put("BOX64_DYNAREC_FASTROUND", "0");
            envVars.put("BOX64_DYNAREC_X87DOUBLE", "1");
            envVars.put("BOX64_DYNAREC_BIGBLOCK", "1");
            envVars.put("BOX64_DYNAREC_STRONGMEM", "2");
            envVars.put("BOX64_DYNAREC_FORWARD", "128");
            envVars.put("BOX64_DYNAREC_CALLRET", "0");
            envVars.put("BOX64_DYNAREC_WAIT", "1");
            envVars.put("BOX64_DYNAREC_NATIVEFLAGS", "0");
            envVars.put("BOX64_DYNAREC_WEAKBARRIER", "0");
        }
        else if (id.equals(Box64Preset.STABILITY)) {''')
patch(p, 'presets.add(new Box64Preset(Box64Preset.STABILITY, context.getString(R.string.stability)));',
      '''presets.add(new Box64Preset(TITANX_BALANCED, "TitanX 8GB Balanced"));
        presets.add(new Box64Preset(TITANX_LOW_RAM, "TitanX 8GB Low RAM"));
        presets.add(new Box64Preset(Box64Preset.STABILITY, context.getString(R.string.stability)));''')

p='app/src/main/java/com/winlator/ContainerDetailFragment.java'
patch(p, 'loadScreenSizeSpinner(view, isEditMode() ? container.getScreenSize() : Container.DEFAULT_SCREEN_SIZE);',
      'loadScreenSizeSpinner(view, isEditMode() ? container.getScreenSize() : (TitanXDevice.isOptimizedDevice(context) ? "960x540" : Container.DEFAULT_SCREEN_SIZE));')
patch(p, 'Box64PresetManager.loadSpinner(sBox64Preset, isEditMode() ? container.getBox64Preset() : preferences.getString("box64_preset", Box64Preset.DEFAULT));',
      'Box64PresetManager.loadSpinner(sBox64Preset, isEditMode() ? container.getBox64Preset() : preferences.getString("box64_preset", TitanXDevice.isOptimizedDevice(context) ? Box64PresetManager.TITANX_BALANCED : Box64Preset.DEFAULT));')

# Correct the global GTA5 512MB override. DXGI values are *reported VRAM*, not a physical RAM cap.
p='app/src/main/java/com/winlator/contentdialog/DXVKConfigDialog.java'
patch(p,'import com.winlator.R;', 'import com.winlator.R;\nimport com.winlator.TitanXDevice;')
patch(p,'String content = getDXVKConfigContent(config);','String content = getDXVKConfigContent(context, config);')
patch(p,'private static String getDXVKConfigContent(KeyValueSet config) {',
      'private static String getDXVKConfigContent(Context context, KeyValueSet config) {')
patch(p, '''        content += "[GTA5.exe]\\n";
        content += "dxgi.maxDeviceMemory = 512\\n";
        content += "dxgi.maxSharedMemory = 512\\n";
        return content;''',
      '''        // Do not advertise only 512 MB of VRAM to GTA5.exe unconditionally.
        // Limit simultaneous shader compilation on the target RAM 8GB device.
        if (TitanXDevice.isOptimizedDevice(context)) {
            content += "dxvk.numCompilerThreads = 2\\n";
            // May reduce pipeline memory on supported DXVK versions.
            content += "dxvk.trackPipelineLifetime = True\\n";
        }
        return content;''')

# Reduce on-disk Mesa shader cache max size (not a physical RAM limit).
patch('app/src/main/java/com/winlator/container/Container.java',
      'MESA_SHADER_CACHE_MAX_SIZE=512MB',
      'MESA_SHADER_CACHE_MAX_SIZE=128MB')

notes=ROOT/'TITANX_CHANGES.txt'
notes.write_text('''TitanX 8GB Driver Manager prototype: source modifications applied 2026-10-20.
Based on: https://github.com/brunodev85/winlator-app commit 8077f374ef2d54127b088de9e8cd7b4af14d9c8b
Changes: distinct package identity; target-device default screen 960x540; two optional Box64 presets;
Turnip version suffix preserved; added packaged versions to Turnip and DXVK dropdowns;
removed unconditional DXVK GTA5 512MB reported VRAM override; limited shader compiler threads
and enabled pipeline lifetime tracking when supported on S23 Ultra RAM8.
No FEX runtime is included. No gameplay/performance validation on S23 Ultra was performed.
Third-party component licenses/attribution remain applicable. See original project license and docs.
''',encoding='utf-8')

for f in [
 'app/src/main/assets/rootfs.tzst',
 'app/src/main/assets/graphics_driver/turnip-27.0.0-r3-8G2.tzst',
 'app/src/main/assets/dxwrapper/dxvk-2.4.1-user.tzst',
 'app/src/main/assets/dxwrapper/dxvk-2.6.9-gplall-test.tzst',
]:
    file=ROOT/f
    if not file.is_file() or file.stat().st_size<1024:raise ValueError(f'Missing required binary asset: {f}')
    print('VERIFIED',f,file.stat().st_size)

print('TITANX DRIVER PATCH COMPLETED: source only, not Android APK build.')
