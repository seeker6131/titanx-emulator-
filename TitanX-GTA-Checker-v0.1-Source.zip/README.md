# TitanX GTA Lite Compatibility Checker v0.1

A standalone **Android game-data checker**, not a GTA V port, emulator, or game launcher.

## What it does

- Select any accessible GTA V folder with Android's Storage Access Framework, without broad filesystem access permission.
- Query **file names and file sizes**, not the content of huge game archives.
- Check `common.rpf`, root `x64*.rpf`, `update/update.rpf`, `update/update2.rpf`, `update/x64/metadata.dat`, `update/x64/dlcpacks/` and count DLC directories.
- Export a TXT report via Android's save document picker or copy the result to clipboard.
- Works entirely offline, read-only. Never copies or modifies your 44GB+ game assets.
- Deliberately displays **UNKNOWN** for the underlying GTA V build; version guesses based on file size are not valid.

## Build via GitHub Actions

Use `.github/workflows/titanx-gta-checker.yml`, which builds `titanx-gta-checker/app` independently of old TitanX/Winlator modules. In Actions, run **TitanX GTA Compatibility Checker** → **Run workflow** → download the artifact `TitanX-GTA-Checker-v0.1-APK`.

## Use

On your phone, open the APK, choose the GTA V **top-level directory** containing `common.rpf` and `update/`. Wait for the report then tap **Copy** or **Save TXT**. Selecting only `update/` gives false misses.

## Next engineering gate

A good structure score **does not show** the game is compatible with an ARM64 native GTA V runtime. That requires an engine with verified rights, a tested target build, and actual phone-level test logs. The checker intentionally does not bundle a game or a third-party engine.

## License

The checker source code written for this project is provided under MIT (see `LICENSE`). This license applies only to the new checker code, not to Grand Theft Auto V, third-party runtime binaries, or any game data.

## One-ZIP GitHub/mobile method

For a phone-only setup, upload the intact `TitanX-GTA-Checker-v0.1-Source.zip` to your repo root.
Create `.github/workflows/titanx-gta-checker-build.yml` using the accompanying `titanx-gta-checker-build.yml` content. This workflow extracts the source ZIP and builds the APK. This avoids manually creating the nested Java project files from a phone.

The included `.github/workflows/titanx-gta-checker.yml` is an alternative for projects where you commit the extracted folder tree instead of uploading the ZIP.
