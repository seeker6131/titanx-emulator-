package com.titanx.gtachecker;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int PICK_GAME_DIR = 501;
    private static final int EXPORT_REPORT = 502;
    private static final int BG = 0xff0b1325;
    private static final int SURFACE = 0xff172238;
    private static final int TEXT = 0xfff4f7ff;
    private static final int MUTED = 0xffaabbd6;
    private static final int CYAN = 0xff56e0dc;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView reportView;
    private TextView statusView;
    private Button exportButton;
    private Button copyButton;
    private Button scanButton;
    private String reportText = "";
    private Uri pickedFolder;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        setUpInterface();
        String saved = getPreferences(MODE_PRIVATE).getString("game_tree", "");
        if (!saved.isEmpty()) {
            pickedFolder = Uri.parse(saved);
            statusView.setText("บันทึกโฟลเดอร์ที่เคยเลือกไว้แล้ว • กดตรวจอีกครั้งได้");
        }
    }

    private GradientDrawable panel(int color, int stroke) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), stroke);
        return bg;
    }

    private int dp(int n) {
        return (int) (getResources().getDisplayMetrics().density * n + 0.5f);
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setLineSpacing(dp(2), 1.08f);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button action(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(primary ? BG : CYAN);
        b.setBackgroundTintList(ColorStateList.valueOf(primary ? CYAN : 0xff263750));
        b.setMinimumHeight(dp(48));
        return b;
    }

    private void setUpInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(24), dp(20), dp(32));
        scroll.addView(page);
        setContentView(scroll);

        TextView eyebrow = text("TITANX  /  GTA V NATIVE RESEARCH", 11, CYAN, true);
        page.addView(eyebrow);
        TextView title = text("GTA V Lite\nCompatibility Checker", 25, TEXT, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(12);
        page.addView(title, titleLp);

        TextView subtitle = text("สำหรับ Snapdragon 8 Gen 2 / RAM 8GB\nตรวจโครงสร้างเกม Windows โดยไม่แก้ไขไฟล์ หรือส่งข้อมูลขึ้นเซิร์ฟเวอร์", 14, MUTED, false);
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(-1, -2);
        subtitleLp.topMargin = dp(12);
        page.addView(subtitle, subtitleLp);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(14), dp(12), dp(14), dp(12));
        controls.setBackground(panel(SURFACE, 0xff263851));
        LinearLayout.LayoutParams controlLp = new LinearLayout.LayoutParams(-1, -2);
        controlLp.topMargin = dp(22);
        page.addView(controls, controlLp);

        Button pickButton = action("เลือกโฟลเดอร์ GTA V Lite", true);
        controls.addView(pickButton, new LinearLayout.LayoutParams(-1, dp(54)));
        pickButton.setOnClickListener(v -> chooseDirectory());

        scanButton = action("ตรวจโฟลเดอร์ที่เลือกอีกครั้ง", false);
        LinearLayout.LayoutParams scanLp = new LinearLayout.LayoutParams(-1, dp(52));
        scanLp.topMargin = dp(8);
        controls.addView(scanButton, scanLp);
        scanButton.setOnClickListener(v -> {
            if (pickedFolder == null) {
                Toast.makeText(this, "กรุณาเลือกโฟลเดอร์เกมก่อน", Toast.LENGTH_SHORT).show();
                return;
            }
            scan(pickedFolder);
        });

        statusView = text("พร้อมตรวจ • เลือกโฟลเดอร์หลักที่มี GTA5.exe, update และ common.rpf", 12, MUTED, false);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = dp(13);
        controls.addView(statusView, statusLp);

        TextView head = text("ผลตรวจ", 18, TEXT, true);
        LinearLayout.LayoutParams headLp = new LinearLayout.LayoutParams(-1, -2);
        headLp.topMargin = dp(25);
        page.addView(head, headLp);

        LinearLayout resultPanel = new LinearLayout(this);
        resultPanel.setOrientation(LinearLayout.VERTICAL);
        resultPanel.setPadding(dp(16), dp(16), dp(16), dp(18));
        resultPanel.setBackground(panel(SURFACE, 0xff263851));
        LinearLayout.LayoutParams resultLp = new LinearLayout.LayoutParams(-1, -2);
        resultLp.topMargin = dp(10);
        page.addView(resultPanel, resultLp);

        reportView = text("ยังไม่มีผลตรวจ\n\nแอปจะตรวจชื่อและขนาดไฟล์โดยไม่เปิดแก้ไฟล์ .rpf ขนาดใหญ่", 13, MUTED, false);
        reportView.setTextIsSelectable(true);
        resultPanel.addView(reportView);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams buttonsLp = new LinearLayout.LayoutParams(-1, -2);
        buttonsLp.topMargin = dp(12);
        page.addView(buttons, buttonsLp);

        exportButton = action("บันทึกรายงาน TXT", false);
        copyButton = action("คัดลอกผลตรวจ", false);
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(52), 1);
        buttons.addView(exportButton, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(52), 1);
        half2.leftMargin = dp(10);
        buttons.addView(copyButton, half2);
        exportButton.setEnabled(false);
        copyButton.setEnabled(false);
        exportButton.setOnClickListener(v -> exportReport());
        copyButton.setOnClickListener(v -> {
            ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("TitanX report", reportText));
            Toast.makeText(this, "คัดลอกรายงานแล้ว", Toast.LENGTH_SHORT).show();
        });

        TextView disclaimer = text("ตรวจโครงสร้างข้อมูลเท่านั้น • ไม่ตรวจ DRM • ไม่ยืนยันว่าเล่นผ่าน XHYN V/Rush5 ได้ • ไม่ใช่ตัวพอร์ตหรือ Emulator", 12, MUTED, false);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1, -2);
        dlp.topMargin = dp(20);
        page.addView(disclaimer, dlp);
    }

    private void chooseDirectory() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, PICK_GAME_DIR);
        } catch (Exception e) {
            statusView.setText("เปิดตัวเลือกโฟลเดอร์ไม่ได้: " + e.getMessage());
        }
    }

    private void exportReport() {
        if (reportText.isEmpty()) return;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, "TitanX-GTA-Lite-report.txt");
        try {
            startActivityForResult(intent, EXPORT_REPORT);
        } catch (Exception e) {
            statusView.setText("เปิดหน้าบันทึกรายงานไม่ได้: " + e.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == PICK_GAME_DIR) {
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (SecurityException ignored) {
                // Some document providers do not support persistent grants.
            }
            pickedFolder = uri;
            getPreferences(MODE_PRIVATE).edit().putString("game_tree", uri.toString()).apply();
            scan(uri);
        } else if (requestCode == EXPORT_REPORT) {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                if (out == null) throw new IOException("Cannot open output stream");
                out.write(reportText.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, "บันทึกรายงานแล้ว", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                statusView.setText("บันทึกรายงานไม่สำเร็จ: " + e.getMessage());
            }
        }
    }

    private void scan(Uri tree) {
        scanButton.setEnabled(false);
        reportView.setText("กำลังตรวจรายชื่อไฟล์จาก Android Storage Access Framework…\nไม่มีการอ่านไฟล์ RPF ทั้งก้อน");
        statusView.setText("กำลังตรวจ... กรุณาเปิดแอปทิ้งไว้สักครู่");
        exportButton.setEnabled(false);
        copyButton.setEnabled(false);
        worker.execute(() -> {
            String result;
            try {
                result = runInspection(tree);
            } catch (Exception e) {
                result = "TitanX Checker: ตรวจไม่สำเร็จ\n" + e.getClass().getSimpleName() + ": " + e.getMessage()
                       + "\n\nตรวจสิทธิ์เข้าถึงโฟลเดอร์ แล้วเลือกโฟลเดอร์หลัก GTA V อีกครั้ง";
            }
            final String finalReport = result;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                reportText = finalReport;
                reportView.setText(finalReport);
                reportView.setTextColor(TEXT);
                statusView.setText("ตรวจเสร็จแล้ว • สามารถคัดลอกหรือบันทึกรายงานได้");
                scanButton.setEnabled(true);
                exportButton.setEnabled(true);
                copyButton.setEnabled(true);
            });
        });
    }

    private static final class Entry {
        final String name;
        final String id;
        final String type;
        final long size;
        Entry(String name, String id, String type, long size) {
            this.name = name; this.id = id; this.type = type; this.size = size;
        }
        boolean folder() { return DocumentsContract.Document.MIME_TYPE_DIR.equals(type); }
    }

    private List<Entry> children(Uri tree, String parentId) throws IOException {
        Uri listUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
        String[] projection = {
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        };
        List<Entry> results = new ArrayList<>();
        try (Cursor cursor = getContentResolver().query(listUri, projection, null, null, null)) {
            if (cursor == null) throw new IOException("Android ไม่อนุญาตให้อ่านรายชื่อไฟล์ในโฟลเดอร์นี้");
            int idIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            int nameIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            int typeIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
            int sizeIndex = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);
            if (idIndex < 0 || nameIndex < 0 || typeIndex < 0) throw new IOException("File provider ขาด metadata ที่ต้องใช้");
            while (cursor.moveToNext()) {
                if (results.size() >= 10000) throw new IOException("โฟลเดอร์มีรายการมากเกิน 10,000 รายการ");
                String id = cursor.getString(idIndex);
                String name = cursor.getString(nameIndex);
                String type = cursor.getString(typeIndex);
                long size = sizeIndex >= 0 && !cursor.isNull(sizeIndex) ? cursor.getLong(sizeIndex) : -1L;
                if (id != null && name != null) results.add(new Entry(name, id, type, size));
            }
        } catch (SecurityException e) {
            throw new IOException("ไม่ได้รับสิทธิ์อ่านโฟลเดอร์ กรุณาเลือกใหม่", e);
        }
        return results;
    }

    private static Map<String, Entry> lookup(List<Entry> items) {
        Map<String, Entry> map = new HashMap<>();
        for (Entry x : items) map.put(x.name.toLowerCase(Locale.ROOT), x);
        return map;
    }

    private static Entry file(Map<String, Entry> map, String name) {
        Entry x = map.get(name.toLowerCase(Locale.ROOT));
        return x != null && !x.folder() ? x : null;
    }

    private static Entry dir(Map<String, Entry> map, String name) {
        Entry x = map.get(name.toLowerCase(Locale.ROOT));
        return x != null && x.folder() ? x : null;
    }

    private static String status(Entry file) {
        if (file == null) return "ไม่พบ";
        if (file.size == 0) return "พบแต่ไฟล์ว่าง 0 B";
        return file.size < 0 ? "พบ (ไม่ทราบขนาด)" : "พบ • " + formatSize(file.size);
    }

    private static String formatSize(long size) {
        if (size < 0) return "ขนาดไม่ทราบ";
        if (size == 0) return "0 B";
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        double val = size;
        int unit = 0;
        while (val >= 1024 && unit < units.length - 1) { val /= 1024; unit++; }
        return String.format(Locale.US, "%.2f %s", val, units[unit]);
    }

    private String runInspection(Uri tree) throws IOException {
        String rootId;
        try { rootId = DocumentsContract.getTreeDocumentId(tree); }
        catch (Exception e) { throw new IOException("โฟลเดอร์ที่เลือกไม่ใช่ Document Tree ที่อ่านได้", e); }
        List<Entry> top = children(tree, rootId);
        Map<String, Entry> root = lookup(top);
        Entry update = dir(root, "update");
        Entry mainX64 = dir(root, "x64");
        Entry common = file(root, "common.rpf");
        Entry gtaExe = file(root, "GTA5.exe");

        List<Entry> updateItems = update == null ? Collections.emptyList() : children(tree, update.id);
        Map<String, Entry> upd = lookup(updateItems);
        Entry updX64 = dir(upd, "x64");
        Entry updateRpf = file(upd, "update.rpf");
        Entry update2 = file(upd, "update2.rpf");
        List<Entry> updateX64Items = updX64 == null ? Collections.emptyList() : children(tree, updX64.id);
        Map<String, Entry> updateX64 = lookup(updateX64Items);
        Entry dlcpacks = dir(updateX64, "dlcpacks");
        Entry metadata = file(updateX64, "metadata.dat");
        List<Entry> dlcItems = dlcpacks == null ? Collections.emptyList() : children(tree, dlcpacks.id);

        List<Entry> rootRpfs = new ArrayList<>();
        long rootRpfBytes = 0;
        for (Entry e : top) if (!e.folder() && e.name.toLowerCase(Locale.ROOT).endsWith(".rpf")) {
            rootRpfs.add(e);
            if (e.size > 0) rootRpfBytes += e.size;
        }
        rootRpfs.sort(Comparator.comparing(x -> x.name.toLowerCase(Locale.ROOT)));
        int dlcDirs = 0;
        for (Entry e : dlcItems) if (e.folder()) dlcDirs++;
        int basicChecks = 0;
        if (common != null && common.size != 0) basicChecks++;
        if (updateRpf != null && updateRpf.size != 0) basicChecks++;
        if (mainX64 != null) basicChecks++;
        if (dlcpacks != null) basicChecks++;
        if (rootRpfs.size() >= 5) basicChecks++;

        StringBuilder sb = new StringBuilder();
        sb.append("TITANX GTA LITE — DATA COMPATIBILITY REPORT\n");
        sb.append("Checker version: 0.1.0\n");
        sb.append("Time: ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())).append("\n");
        sb.append("Source: Android SAF (read-only metadata queries)\n\n");
        sb.append("STRUCTURE SCORE: ").append(basicChecks).append("/5\n");
        if (basicChecks == 5) sb.append("Outcome: โครงสร้างพื้นฐานดูครบ แต่ยังไม่ยืนยันว่าเล่นกับเอนจิน ARM64 ได้\n");
        else sb.append("Outcome: มีไฟล์หลักที่ไม่พบ กรุณาตรวจว่าเลือกโฟลเดอร์เกมชั้นนอกสุดแล้ว\n");

        sb.append("\n[ROOT]\n");
        sb.append("common.rpf: ").append(status(common)).append("\n");
        sb.append("GTA5.exe: ").append(status(gtaExe)).append(" (Windows executable; ไม่ใช่ ARM64)\n");
        sb.append("x64/: ").append(mainX64 != null ? "พบ" : "ไม่พบ").append("\n");
        sb.append("*.rpf at root: ").append(rootRpfs.size()).append(" ไฟล์\n");
        sb.append("Total known root RPF size: ").append(formatSize(rootRpfBytes)).append("\n");
        for (Entry e : rootRpfs) sb.append("  ").append(e.name).append(" • ").append(formatSize(e.size)).append("\n");

        sb.append("\n[UPDATE]\n");
        sb.append("update/: ").append(update != null ? "พบ" : "ไม่พบ").append("\n");
        sb.append("update/update.rpf: ").append(status(updateRpf)).append("\n");
        sb.append("update/update2.rpf: ").append(status(update2)).append(" (optional/version-specific)\n");
        sb.append("update/x64/: ").append(updX64 != null ? "พบ" : "ไม่พบ").append("\n");
        sb.append("update/x64/metadata.dat: ").append(status(metadata)).append("\n");
        sb.append("update/x64/dlcpacks/: ").append(dlcpacks != null ? "พบ" : "ไม่พบ").append("\n");
        sb.append("DLC folders: ").append(dlcDirs).append("\n");
        List<String> dlcNames = new ArrayList<>();
        for (Entry e : dlcItems) if (e.folder()) dlcNames.add(e.name);
        Collections.sort(dlcNames, String.CASE_INSENSITIVE_ORDER);
        for (String dlcName : dlcNames) sb.append("  • ").append(dlcName).append("\n");

        sb.append("\n[ENGINE COMPATIBILITY]\n");
        sb.append("Actual GTA V game build: UNKNOWN (ไม่สามารถอ่านได้จากชื่อ/ขนาด RPF)\n");
        sb.append("XHYN V / Rush5 compatibility: NOT TESTED\n");
        sb.append("Windows DLL, ASI และ mod loader ใช้กับ ARM64 Native ไม่ได้โดยตรง\n");
        sb.append("การตัดไฟล์ใน GTA V Lite อาจทำให้โหลดไม่ผ่าน แม้โครงสร้างดูครบ\n");
        sb.append("ห้ามสรุป Build 2699/2824/2845 จากขนาดเกมโดยลำพัง\n");
        sb.append("\n[NEXT STEP]\n");
        sb.append("ส่งรายงานนี้ให้ตรวจ เพื่อเทียบ manifest ที่เอนจิน ARM64 ต้องการ\n");
        sb.append("ต้องตรวจความถูกต้องของสิทธิ์ใช้และแจกจ่าย runtime แยกต่างหาก\n");
        sb.append("ไม่มีการแก้ไฟล์เกม ไม่มีการดึงข้อมูลออกจากโทรศัพท์\n");
        return sb.toString();
    }

    @Override
    protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }
}
